import './style.css'
const app = document.querySelector("#app");
if(app){
    app.innerHTML = `
    <div class="configurator-card">
        <header class="header">
            <h1>Configurador de Vehículo</h1>
            <p>Personaliza las especificaciones técnicas y acabados de tu coche</p>
        </header>
        <form action="#" id="formulario" method="post">
            <div class="form-grid">
                <!-- 1. Motorización -->
                <div class="form-group">
                    <label class="field-label" for="motor">Motorización</label>
                    <select id="motor" name="motor" required>
                        <option value="" disabled selected>Selecciona un motor</option>
                        <option value="gasolina">Gasolina — 7.500 € (Base)</option>
                        <option value="diesel">Diésel — 9.200 € (Base)</option>
                    </select>
                </div>
                <!-- 2. Potencia / Cilindrada -->
                <div class="form-group">
                    <label class="field-label" for="potencia">Cilindrada / Potencia</label>
                    <select id="potencia" name="potencia" required>
                        <option value="" disabled selected>Selecciona cilindrada</option>
                        <option value="1200">1200 cc (+900 €)</option>
                        <option value="1900">1900 cc (+2.100 €)</option>
                        <option value="2300">2300 cc (+2.600 €)</option>
                    </select>
                    <span class="restriction-note">El motor diésel no se puede fabricar con 2300 cc.</span>
                </div>
                <!-- 3. Tipo de Pintura -->
                <div class="form-group">
                    <label class="field-label" for="pintura">Tipo de Pintura</label>
                    <select id="pintura" name="pintura" required>
                        <option value="" disabled selected>Selecciona tipo de pintura</option>
                        <option value="normal">Normal (+750 €)</option>
                        <option value="mate">Mate (+1.400 €)</option>
                        <option value="metalizada">Metalizada (+1.580 €)</option>
                    </select>
                </div>
                <!-- 4. Color de Carrocería -->
                <div class="form-group">
                    <label class="field-label" for="color">Color</label>
                    <select id="color" name="color" required>
                        <option value="" disabled selected>Selecciona un color</option>
                        <option value="negro">Negro</option>
                        <option value="blanco">Blanco</option>
                        <option value="rojo">Rojo</option>
                        <option value="azul">Azul</option>
                        <option value="verde">Verde</option>
                        <option value="gris">Gris</option>
                    </select>
                    <span class="restriction-note">Pintura normal no disponible en azul, verde ni gris.</span>
                </div>
            </div>
            <!-- 5. Extras Opcionales -->
            <fieldset class="extras-section" style="border: none;">
                <legend>Equipamiento y Extras Opcionales</legend>
                <div class="extras-grid">
                    <label class="extra-card">
                        <input type="checkbox" name="extras" id="aleron" value="aleron">
                        <div class="extra-info">
                            <span class="extra-title">Alerón deportivo</span>
                            <span class="extra-price">+190 €</span>
                             <span class="extra-subtext">* Requiere pintura metalizada</span>
                        </div>
                    </label>
                    <label class="extra-card">
                        <input type="checkbox" name="extras" id="radio" value="radiocd">
                        <div class="extra-info">
                            <span class="extra-title">Radio-CD con MP3</span>
                            <span class="extra-price">+230 €</span>
                        </div>
                    </label>
                    <label class="extra-card">
                        <input type="checkbox" name="extras" id="altavoces" value="altavoces">
                        <div class="extra-info">
                            <span class="extra-title">Altavoces gama alta</span>
                            <span class="extra-price">+530 €</span>
                            <span class="extra-subtext">* Requiere Radio-CD previo</span>
                        </div>
                    </label>
                    <label class="extra-card">
                        <input type="checkbox" name="extras" id="gps" value="gps">
                        <div class="extra-info">
                            <span class="extra-title">GPS incorporado</span>
                            <span class="extra-price">+520 €</span>
                        </div>
                    </label>
                </div>
            </fieldset>
            <div class="actions">
                <button type="submit" class="btn btn-primary">Guardar Configuración</button>
                <button type="reset" class="btn btn-secondary">Restablecer</button>
            </div>
        </form>
        <div id="resultado">
            
        </div>
    </div>`;
}
const formulario = document.querySelector("#formulario") as HTMLFormElement;
if(formulario){
    formulario.addEventListener("submit" , (event:SubmitEvent) => {
        event.preventDefault();
        let correcto = true, motor = true, pintColor = true, aleronElegido = true, altavocesEleccion = true;
        
        const tipoSelect = document.querySelector("#motor") as HTMLSelectElement;
        const potenciaSelect = document.querySelector("#potencia") as HTMLSelectElement;
        const pinturaSelect = document.querySelector("#pintura") as HTMLSelectElement;
        const colorSelect = document.querySelector("#color") as HTMLSelectElement;
        const aleronSelect = document.querySelector("#aleron") as HTMLInputElement;
        const radioSelec = document.querySelector("#radio") as HTMLInputElement;
        const altavocesSelec = document.querySelector("#altavoces") as HTMLInputElement;
        const gpsSelect = document.querySelector("#gps") as HTMLInputElement;
        const combustible: string = tipoSelect.value;
        const potencia: string = potenciaSelect.value;
        const pintura: string = pinturaSelect.value;
        const color: string = colorSelect.value;
        // Se usa .checked para saber si el checkbox esta marcado
        const aleron: boolean = aleronSelect.checked;
        const radio: boolean = radioSelec.checked;
        const altavoces: boolean = altavocesSelec.checked;
        const gps: boolean = gpsSelect.checked;
        let precioFinal: number = 0;
        if(combustible.includes("gasolina")) precioFinal += 7500;
        else precioFinal += 9200;
        switch(potencia){
            case "1200": precioFinal += 900; break;
            case "1900": precioFinal += 2100; break;
            case "2300":
                if(combustible.includes("diesel")){
                    motor = false;
                    correcto = false;
                } else precioFinal += 2600;
                break;
        }
        switch(pintura){
            case "normal": precioFinal += 750; break;
            case 'mate': precioFinal += 1400; break;
            case 'metalizada': precioFinal += 1580; break;
        }
        // Si la pintura es normal, no se pueden elegir azul, verde ni gris
        if(pintura.includes("normal")){
            if(color.includes('azul') || color.includes('verde') || color.includes('gris')){
                pintColor = false;
                correcto = false;
            }
        }
        // Aleron solo disponible con pintura metalizada
        if(aleron){
            if(pintura != 'metalizada'){
                correcto = false;
                aleronElegido = false;
            } else {
                precioFinal += 190;
            }
        }
        // Radio
        if(radio) precioFinal += 230;
        // Altavoces solo si antes se eligio la radio
        if(altavoces){
            if(!radio){
                altavocesEleccion = false;
                correcto = false;
            } else {
                precioFinal += 530;
            }
        }
        // GPS
        if(gps) precioFinal += 520;
        if(!correcto) alert(`${!motor ? "No se puede tener un motor diesel de 2300.":''} ${!pintColor ? ` No se puede tener una pintura de color ${color} con la eleccion de pintura normal.` : '' } ${!aleronElegido ? ' No puedes elegir aleron si no tienes la pintura metalizada.' :''} ${!altavocesEleccion ? ' No puedes elegir altavoces sin elegir antes la radio.': ''}`)
        else {
            const resultado = document.querySelector("#resultado") as HTMLElement;
            resultado.innerHTML = `<p>Tienes que pagar: ${precioFinal}</p>`
        } 
    })
}